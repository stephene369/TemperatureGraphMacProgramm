"""
Package core - Contient la logique métier de l'application ClimaGraph
"""
